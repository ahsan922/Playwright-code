REMOTE_URL="https://github.com/mozilla/gecko-dev"
BASE_BRANCH="release"
BASE_REVISION="7ab3cc0103090dd7bfa02e072a529b9fc784ab4e"
