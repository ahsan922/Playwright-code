REMOTE_URL="https://github.com/WebKit/WebKit.git"
BASE_BRANCH="main"
BASE_REVISION="bc0bc692bc9e368bbd9d530322db73b374cd6268"
