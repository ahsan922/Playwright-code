module.exports = {
  extends: "../.eslintrc-with-ts-config.js",
};
