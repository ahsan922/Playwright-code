export default {
  testDir: '../../tests',
  reporter: [['markdown'], ['html']]
};